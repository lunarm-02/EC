package 効果測定_川越.Abstract_character;

public abstract class Character implements Abstract_character {

    public void run(){
        // 実装確認
        System.out.println("モンスターは走って逃げた");
    }

    // 実装確認
    public abstract void attack();


}

