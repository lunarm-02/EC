package 効果測定_川越.Abstract_character;

public interface Abstract_character {
    void run();
}
// すべての生き物が逃げる選択肢がある




