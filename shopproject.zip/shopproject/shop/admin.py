from django.contrib import admin

# Register your models here.

# CustomUserをインポート
from .models import Category, ShopPost, CommentPost, PricePost, CartPost

class CategoryAdmin(admin.ModelAdmin):
    '''管理ページのレコード一覧に表示するカラムを設定するクラス
    
    '''
    # レコード一覧にidとtitleを表示
    list_display = ('id', 'title')
    # 表示するカラムにリンクを設定
    list_display_links = ('id', 'title')


class ShopPostAdmin(admin.ModelAdmin):
    '''管理ページのレコード一覧に表示するカラムを設定するクラス

    '''
    # レコード一覧にidとtitleを表示
    list_display = ('id', 'title', )
    # 表示するカラムにリンクを設定
    list_display_links = ('id', 'title', )

class CommentPostAdmin(admin.ModelAdmin):
    '''管理ページのレコード一覧に表示するカラムを設定するクラス'''
    list_display = ('id', 'shop_post', 'text', 'rating', 'created_at')
    list_display_links = ('id', 'shop_post', 'text')

class PricePostAdmin(admin.ModelAdmin):
    '''管理ページのレコード一覧に表示するカラムを設定するクラス'''
    list_display = ('id', 'shop_post', 'price', 'quantity')
    list_display_links = ('id', 'shop_post')

class CartPostadmin(admin.ModelAdmin):

    # ユーザー名を表示するカスタムメソッド
    def user_username(self, obj):
        return obj.user.username
    user_username.short_description = 'ユーザー名'  # 列名のカスタマイズ

    # 投稿タイトルを表示するカスタムメソッド
    def shop_post_title(self, obj):
        return obj.shop_post.title
    shop_post_title.short_description = '投稿タイトル'  # 列名のカスタマイズ
    # レコード一覧にidとtitleを表示
    list_display = ('id', 'user_username', 'shop_post_title', 'quantity2')
    # 表示するカラムにリンクを設定
    list_display_links = ('id', 'user_username', 'shop_post_title', 'quantity2')



# class ShopPostAdmin(admin.ModelAdmin):
#     list_display = ['category', 'title', 'comment', 'get_price']
#     inlines = [PricePostInline, CommentPostInline]

#     def get_price(self, obj):
#         try:
#             price_post = obj.pricepost
#             return price_post.price if price_post else 'N/A'
#         except PricePost.DoesNotExist:
#             return 'N/A'
#     get_price.admin_order_field = 'price'
#     get_price.short_description = 'Price'

# Django管理サイトにShopPost、ShopPostAdminを登録する
admin.site.register(ShopPost, ShopPostAdmin)
# Django管理サイトにCategory、CategoryAdminを登録する
admin.site.register(Category, CategoryAdmin)
# Django管理サイトにCommentPost、CommentPostAdminを登録する
admin.site.register(CommentPost, CommentPostAdmin)
# Django管理サイトにPricePost、PricePostAdminを登録する
admin.site.register(PricePost, PricePostAdmin)
# Django管理サイトにCarttPost、CartPostAdminを登録する
admin.site.register(CartPost, CartPostadmin)



# # Django管理サイトにPhotoPost、PhotoPostAdminを登録する
# admin.site.register(CommentPost, ShopPostAdmin)

