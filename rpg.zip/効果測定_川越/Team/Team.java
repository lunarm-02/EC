package 効果測定_川越.Team;

public enum Team{
    hero,
    monster_devil,
    monster_goblin,
    arry
}