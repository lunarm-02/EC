from django.urls import path
from .import views




app_name = 'shop'

urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    
    # 写真投稿ページへのアクセスはviewsモジュールのCreatePhotoViewを実行
    path('shop_display/', views.CreateShopView.as_view(), name='shop_display'),

    # 投稿完了ページへのアクセスはviewsモジュールのPostSuccessViewを実行
    path('shop_display_success/', views.Shop_display_SuccessView.as_view(), name='shop_display_success'),
    
    # カテゴリー覧ページ
    # photos/<categorysテーブルのid値>にマッチング
    # <int:category>は辞書{category: id値(int)}としてcategoryViewに渡される
    path('by_category/<int:category>', views.By_categoryView.as_view(), name='by_category'),

    # ユーザの投稿一覧ページ
    # photos/<ユーザーテーブルのid値>にマッチング
    # <int:user>は辞書{user: id値(int)}としてCategoryViewに渡される
    path('usercategory/<int:user>', views.UserView.as_view(), name='usercategory'),
    
    # 詳細ページ
    # photo-detail/<Photo postsテーブルのid値>にマッチング
    # <int:pk>は辞書{pk: id値(int)}としてDetailViewに渡される
    path('detail/<int:pk>', views.ShopPostDetailView.as_view(), name='detail'),

    # コメント投稿ページへのアクセスはviewsモジュールのCreatePhotoViewを実行
    path('comment_display/<int:shop_post_id>', views.Comment_display_View.as_view(), name='comment_display'),

    # コメント投稿完了ページへのアクセスはviewsモジュールのPostSuccessViewを実行
    path('comment_display_success/', views.Comment_display_SuccessView.as_view(), name='comment_display_success'),

    path('add_to_cart/<int:shop_post_id>/', views.add_to_cart, name='add_to_cart'),

    path('cartdetail/', views.CartDetailPostView.as_view(), name='cartdetail')

]