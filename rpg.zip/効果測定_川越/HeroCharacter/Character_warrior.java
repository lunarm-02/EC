package 効果測定_川越.HeroCharacter;

import 効果測定_川越.Abstract_character.Character;
import 効果測定_川越.CharacterCreation.*;
import 効果測定_川越.Team.*;


// 戦士の作成
public class Character_warrior extends Character {
    private CharacterCreate characterwarrior;

    public Character_warrior(){
        characterwarrior = new CharacterCreate.Builder(Team.hero, "戦士", 5000, 500, 3)
                            .recovery(1000)
                            .defence(500)
                            .majical(1000)
                            .build();
    }

    public void attack(){
        int power = characterwarrior.get_power() + 1000;
        characterwarrior.set_currentpower(power);
        System.out.println("戦士は大斧で攻撃した！");
    }
}