package 効果測定_川越;

import java.util.*;
import 効果測定_川越.Abstract_character.*;
import 効果測定_川越.CharacterCreation.*;
import 効果測定_川越.HeroCharacter.*;
import 効果測定_川越.MonsterCharacter.*;
import 効果測定_川越.Team.Team;
import java.time.LocalTime;

public class BattleSimulator0 {
    public static void main(String[] args) {
        // 作成したキャラクターを動的リストで管理
        List<Abstract_character> charactercreates_hero = new ArrayList<>();
        List<Abstract_character> charactercreates_monster = new ArrayList<>();

        try {
            // 勇者
            charactercreates_hero.add(new Character_hero());
            // 戦士
            charactercreates_hero.add(new Character_warrior());
            // 魔法使い
            charactercreates_hero.add(new Character_wizard());
            // 聖女
            charactercreates_hero.add(new Character_saint());
            // 剣士
            charactercreates_hero.add(new Character_sword());
            // 下級モンスター：ゴブリンオーガ
            charactercreates_monster.add(new Character_monster_goblinogre());
            // 中級モンスター：ゴブリンキング
            charactercreates_monster.add(new Character_monster_goblinking());
            // 魔王
            charactercreates_monster.add(new Character_monster_devil());
            // ヴァンパイア
            charactercreates_monster.add(new Character_monster_vampire());
            
            for (Abstract_character character : charactercreates_hero){
                BattleCharacter battleCharacter = new BattleCharacter(character);
            }
            
            
            LocalTime nowtime = LocalTime.now();

            if (2< nowtime.getHour() && nowtime.getHour() < 12){
                System.out.println("おはようございますプレイヤーさん");
            }
            else if (12 <= nowtime.getHour() && nowtime.getHour() < 19){
                System.out.println("こんにちはプレイヤーさん");
            }
            else{
                System.out.println("こんばんわプレイヤーさん");
            }

            System.out.println("キャラクターが無事に作成されました");
            System.out.println();
        } catch (Exception e) {
            System.out.println("キャラクターの作成中にエラーが発生しました:" + e.getMessage());
            return;
        }

        List<CharacterCreate> charactercreates = new ArrayList<>(charactercreates_hero);
        charactercreates.addAll(charactercreates_monster);
        // 戦闘時間
        turn_process(charactercreates, charactercreates_monster, charactercreates_hero);
    }

    // 各ターンの処理
    private static void turn_process(List<CharacterCreate> charactercreates, List<CharacterCreate> charactercreates_monster, List<CharacterCreate> charactercreates_hero){
        // 陣営ごとにキャラクターをリストに格納
        List<BattleCharacter> heroList = new ArrayList<>();
        List<BattleCharacter> monsterList = new ArrayList<>();
        Random rand = new Random();
        Scanner scanner = new Scanner(System.in);

        //キャラクター管理している動的リストcharactersから魔王陣営と勇者陣営で分ける。
        for (CharacterCreate character : charactercreates) {
            if (character.get_team() == Team.hero) {
                heroList.add(new BattleCharacter(character.get_team(), character.get_name(), character.get_hp(), character.get_power(), character.get_speed(), character.get_recovery(), character.get_defence(), character.get_majical()));
            } else if (character.get_team() == Team.monster_devil) {
                monsterList.add(new BattleCharacter(character.get_team(), character.get_name(), character.get_hp(), character.get_power(), character.get_speed(), character.get_recovery(), character.get_defence(), character.get_majical()));
            }
            else if (character.get_team() == Team.monster_goblin) {
                monsterList.add(new BattleCharacter(character.get_team(), character.get_name(), character.get_hp(), character.get_power(), character.get_speed()));
            }
        }


        while (!monsterList.isEmpty()) {

            // ここで戦闘するか休憩するかステータス表示するかを選べるようにする


            try {
                // 進みたい方向を４つの中から選ぶ
                System.out.println("==========戦闘モードを選択しました==========");
                System.out.print("0:前　1:右　2:左　3:後ろ　四つの中から進みたい方向を選択して下さい：");
                int direction = scanner.nextInt();
                if (direction < 0 || direction  > 3){
                    System.out.println("無効な入力値です。0~3の数値を入力してください。");
                    continue;
                }
                // 出現させたモンスターを倒せたときはmonsterListから削除とcharacterListからも削除（速さ順でソートする際倒されているキャラは邪魔になる）
                switch (direction){
                    case 0 :{
                        // ここで攻撃をする際のモンスターの攻撃方法選択はcharacter_heroリストから持ち出し、
                        // 攻撃を受ける側の場合はheroListやmonsterListから選択
                        int monster_i = rand.nextInt(monsterList.size());
                        CharacterCreate turn_battlemonster = charactercreates_monster.get(monster_i);
                        BattleCharacter defencemonster = monsterList.get(monster_i);
                        System.out.println(turn_battlemonster.get_name()+ "が現れました！  現在のHp:"+ turn_battlemonster.get_currenthp());
                        charactercreates_hero.add(turn_battlemonster);
                        
                        // 戦闘陣営対決
                        // character_heroの中に少なくともチームごとの所属キャラクターが少なくとも一体存在
                        while (defencemonster.get_currenthp() > 0){

                            // まずはcharactercreatesをキャラクターの速さで降順にソート
                            Collections.sort(charactercreates_hero, new Comparator<CharacterCreate>() {
                                @Override
                                public int compare(CharacterCreate c1, CharacterCreate c2) {
                                    // speed の降順（大きいほうが先に来る）
                                    return Integer.compare(c2.get_speed(), c1.get_speed());
                                        }
                                    });
                            
                            System.out.println();
                            int turn = 1;
                            System.out.println("====ターン" + turn + "====");
                            for (CharacterCreate battlecr : charactercreates_hero){
                                
                                if (battlecr.get_team() == Team.hero){
                                    if (defencemonster.get_currenthp() == 0) break;
                                    System.out.println();
                                    System.out.println(battlecr.get_name() + "の攻撃ターンです。攻撃する魔王陣営は" + turn_battlemonster.get_name() + "です。");
                                    // ここから攻撃処理の追加
                                    //which文でケース１と２で分けて入力で攻撃か回復かを選択。
                                    System.out.print("0:攻撃  1:回復  2:特殊攻撃　　発動したいスキルを選択してください：");
                                    int skill = scanner.nextInt();
                                    switch (skill){
                                        case 0:
                                            defencemonster.take_attack((int) battlecr.get_power());
                                            if (defencemonster.get_currenthp() <= 0){
                                                monsterList.remove(defencemonster);
                                                charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                                charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                                System.out.println();
                                                break;
                                            }
                                            System.out.println();
                                            break;
                                        case 1:
                                            double amount = battlecr.get_recovery();
                                            int recoveryCharacter = 0;
                                            for (BattleCharacter character : heroList){
                                                System.out.println("キャラクター名" + recoveryCharacter + "： "+ character.get_name() + "Hp" + character.get_currenthp());
                                                recoveryCharacter ++;
                                            }
                                            System.out.println("回復したいキャラクターを選択して下さい。");
                                            int hero_i = scanner.nextInt();
                                            heroList.get(hero_i).take_recovery((double) amount);
                                            System.out.println();
                                            break;
                                        case 2:
                                            battlecr.attack();
                                            defencemonster.take_attack((int) battlecr.get_currentpower());
                                            if (defencemonster.get_currenthp() <= 0){
                                                monsterList.remove(defencemonster);
                                                charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                                charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                                System.out.println();
                                                break;
                                            }
                                            System.out.println();
                                            break;
                                        default :
                                            System.out.println("無効な入力です。");
                                            System.out.println();
                                            break;
                                    }
                                }
                                // 魔王陣営の攻撃ターン
                                
                                else if (battlecr.get_team() == Team.monster_devil || battlecr.get_team() == Team.monster_goblin){
                                    if (defencemonster.get_currenthp() == 0) break;
                                    int hero_index = rand.nextInt(heroList.size());
                                    BattleCharacter defencehero = heroList.get(hero_index);
                                    CharacterCreate turn_battlhero = charactercreates_hero.get(hero_index);
                                    System.out.println();
                                    System.out.println(battlecr.get_name()+ "のターン\n" + defencehero.get_name()+ "が攻撃対象に選ばれました！  現在のHp:"+ defencehero.get_currenthp());
                                    // 攻撃処理
                                    defencehero.take_attack((int) battlecr.get_power());
                                    if (defencehero.get_hp() <= 0){
                                        heroList.remove(defencehero);
                                        charactercreates_hero.removeIf(character -> character.equals(turn_battlhero));
                                    }
                                    // 攻撃処理を増やしてモンスターの特殊攻撃をしたいなら
                                    //ここにcharactercreates_monsterから選択しattack
                                }
                                if (defencemonster.get_currenthp() <= 0){
                                    monsterList.remove(defencemonster);
                                    charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                    charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                    System.out.println();
                                    break;
                                }
                                turn++;
                            }
                        
                            //ターン終了時の状態表示
                            System.out.println();
                            diplayteamstatus("勇者陣営", heroList);
                            diplayteamstatus("魔王陣営", monsterList);
                            System.out.println();
                        }
                        break;
                    }
                        
                    case 1 :{
                        // ここで攻撃をする際のモンスターの攻撃方法選択はcharacter_heroリストから持ち出し、
                        // 攻撃を受ける側の場合はheroListやmonsterListから選択
                        int monster_i = rand.nextInt(monsterList.size());
                        CharacterCreate turn_battlemonster = charactercreates_monster.get(monster_i);
                        BattleCharacter defencemonster = monsterList.get(monster_i);
                        System.out.println(turn_battlemonster.get_name()+ "が現れました！  現在のHp:"+ turn_battlemonster.get_currenthp());
                        charactercreates_hero.add(turn_battlemonster);
                        
                        // 戦闘陣営対決
                        // character_heroの中に少なくともチームごとの所属キャラクターが少なくとも一体存在
                        while (defencemonster.get_currenthp() > 0){

                            // まずはcharactercreatesをキャラクターの速さで降順にソート
                            Collections.sort(charactercreates_hero, new Comparator<CharacterCreate>() {
                                @Override
                                public int compare(CharacterCreate c1, CharacterCreate c2) {
                                    // speed の降順（大きいほうが先に来る）
                                    return Integer.compare(c2.get_speed(), c1.get_speed());
                                        }
                                    });
                            
                            System.out.println();
                            int turn = 1;
                            System.out.println("====ターン" + turn + "====");
                            for (CharacterCreate battlecr : charactercreates_hero){
                                
                                if (battlecr.get_team() == Team.hero){
                                    if (defencemonster.get_currenthp() == 0) break;
                                    System.out.println();
                                    System.out.println(battlecr.get_name() + "の攻撃ターンです。攻撃する魔王陣営は" + turn_battlemonster.get_name() + "です。");
                                    // ここから攻撃処理の追加
                                    //which文でケース１と２で分けて入力で攻撃か回復かを選択。
                                    System.out.print("0:攻撃  1:回復  2:特殊攻撃　　発動したいスキルを選択してください：");
                                    int skill = scanner.nextInt();
                                    switch (skill){
                                        case 0:
                                            defencemonster.take_attack((int) battlecr.get_power());
                                            if (defencemonster.get_currenthp() <= 0){
                                                monsterList.remove(defencemonster);
                                                charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                                charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                                System.out.println();
                                                break;
                                            }
                                            System.out.println();
                                            break;
                                        case 1:
                                            double amount = battlecr.get_recovery();
                                            int recoveryCharacter = 0;
                                            for (BattleCharacter character : heroList){
                                                System.out.println("キャラクター名" + recoveryCharacter + "： "+ character.get_name() + "Hp" + character.get_currenthp());
                                                recoveryCharacter ++;
                                            }
                                            System.out.println("回復したいキャラクターを選択して下さい。");
                                            int hero_i = scanner.nextInt();
                                            heroList.get(hero_i).take_recovery((double) amount);
                                            System.out.println();
                                            break;
                                        case 2:
                                            battlecr.attack();
                                            defencemonster.take_attack((int) battlecr.get_currentpower());
                                            if (defencemonster.get_currenthp() <= 0){
                                                monsterList.remove(defencemonster);
                                                charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                                charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                                System.out.println();
                                                break;
                                            }
                                            System.out.println();
                                            break;
                                        default :
                                            System.out.println("無効な入力です。");
                                            System.out.println();
                                            break;
                                    }
                                }
                                // 魔王陣営の攻撃ターン
                                
                                else if (battlecr.get_team() == Team.monster_devil || battlecr.get_team() == Team.monster_goblin){
                                    if (defencemonster.get_currenthp() == 0) break;
                                    int hero_index = rand.nextInt(heroList.size());
                                    BattleCharacter defencehero = heroList.get(hero_index);
                                    CharacterCreate turn_battlhero = charactercreates_hero.get(hero_index);
                                    System.out.println();
                                    System.out.println(battlecr.get_name()+ "のターン\n" + defencehero.get_name()+ "が攻撃対象に選ばれました！  現在のHp:"+ defencehero.get_currenthp());
                                    // 攻撃処理
                                    defencehero.take_attack((int) battlecr.get_power());
                                    if (defencehero.get_hp() <= 0){
                                        heroList.remove(defencehero);
                                        charactercreates_hero.removeIf(character -> character.equals(turn_battlhero));
                                    }
                                    // 攻撃処理を増やしてモンスターの特殊攻撃をしたいなら
                                    //ここにcharactercreates_monsterから選択しattack
                                }
                                if (defencemonster.get_currenthp() <= 0){
                                    monsterList.remove(defencemonster);
                                    charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                    charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                    System.out.println();
                                    break;
                                }
                                turn++;
                            }
                        
                            //ターン終了時の状態表示
                            System.out.println();
                            diplayteamstatus("勇者陣営", heroList);
                            diplayteamstatus("魔王陣営", monsterList);
                            System.out.println();
                        }
                        break;
                    }
                    case 2 :{
                        // ここで攻撃をする際のモンスターの攻撃方法選択はcharacter_heroリストから持ち出し、
                        // 攻撃を受ける側の場合はheroListやmonsterListから選択
                        int monster_i = rand.nextInt(monsterList.size());
                        CharacterCreate turn_battlemonster = charactercreates_monster.get(monster_i);
                        BattleCharacter defencemonster = monsterList.get(monster_i);
                        System.out.println(turn_battlemonster.get_name()+ "が現れました！  現在のHp:"+ turn_battlemonster.get_currenthp());
                        charactercreates_hero.add(turn_battlemonster);
                        
                        // 戦闘陣営対決
                        // character_heroの中に少なくともチームごとの所属キャラクターが少なくとも一体存在
                        while (defencemonster.get_currenthp() > 0){

                            // まずはcharactercreatesをキャラクターの速さで降順にソート
                            Collections.sort(charactercreates_hero, new Comparator<CharacterCreate>() {
                                @Override
                                public int compare(CharacterCreate c1, CharacterCreate c2) {
                                    // speed の降順（大きいほうが先に来る）
                                    return Integer.compare(c2.get_speed(), c1.get_speed());
                                        }
                                    });
                            
                            System.out.println();
                            int turn = 1;
                            System.out.println("====ターン" + turn + "====");
                            for (CharacterCreate battlecr : charactercreates_hero){
                                
                                if (battlecr.get_team() == Team.hero){
                                    if (defencemonster.get_currenthp() == 0) break;
                                    System.out.println();
                                    System.out.println(battlecr.get_name() + "の攻撃ターンです。攻撃する魔王陣営は" + turn_battlemonster.get_name() + "です。");
                                    // ここから攻撃処理の追加
                                    //which文でケース１と２で分けて入力で攻撃か回復かを選択。
                                    System.out.print("0:攻撃  1:回復  2:特殊攻撃　　発動したいスキルを選択してください：");
                                    int skill = scanner.nextInt();
                                    switch (skill){
                                        case 0:
                                            defencemonster.take_attack((int) battlecr.get_power());
                                            if (defencemonster.get_currenthp() <= 0){
                                                monsterList.remove(defencemonster);
                                                charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                                charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                                System.out.println();
                                                break;
                                            }
                                            System.out.println();
                                            break;
                                        case 1:
                                            double amount = battlecr.get_recovery();
                                            int recoveryCharacter = 0;
                                            for (BattleCharacter character : heroList){
                                                System.out.println("キャラクター名" + recoveryCharacter + "： "+ character.get_name() + "Hp" + character.get_currenthp());
                                                recoveryCharacter ++;
                                            }
                                            System.out.println("回復したいキャラクターを選択して下さい。");
                                            int hero_i = scanner.nextInt();
                                            heroList.get(hero_i).take_recovery((double) amount);
                                            System.out.println();
                                            break;
                                        case 2:
                                            battlecr.attack();
                                            defencemonster.take_attack((int) battlecr.get_currentpower());
                                            if (defencemonster.get_currenthp() <= 0){
                                                monsterList.remove(defencemonster);
                                                charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                                charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                                System.out.println();
                                                break;
                                            }
                                            System.out.println();
                                            break;
                                        default :
                                            System.out.println("無効な入力です。");
                                            System.out.println();
                                            break;
                                    }
                                }
                                // 魔王陣営の攻撃ターン
                                
                                else if (battlecr.get_team() == Team.monster_devil || battlecr.get_team() == Team.monster_goblin){
                                    if (defencemonster.get_currenthp() == 0) break;
                                    int hero_index = rand.nextInt(heroList.size());
                                    BattleCharacter defencehero = heroList.get(hero_index);
                                    CharacterCreate turn_battlhero = charactercreates_hero.get(hero_index);
                                    System.out.println();
                                    System.out.println(battlecr.get_name()+ "のターン\n" + defencehero.get_name()+ "が攻撃対象に選ばれました！  現在のHp:"+ defencehero.get_currenthp());
                                    // 攻撃処理
                                    defencehero.take_attack((int) battlecr.get_power());
                                    if (defencehero.get_hp() <= 0){
                                        heroList.remove(defencehero);
                                        charactercreates_hero.removeIf(character -> character.equals(turn_battlhero));
                                    }
                                    // 攻撃処理を増やしてモンスターの特殊攻撃をしたいなら
                                    //ここにcharactercreates_monsterから選択しattack
                                }
                                if (defencemonster.get_currenthp() <= 0){
                                    monsterList.remove(defencemonster);
                                    charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                    charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                    System.out.println();
                                    break;
                                }
                                turn++;
                            }
                        
                            //ターン終了時の状態表示
                            System.out.println();
                            diplayteamstatus("勇者陣営", heroList);
                            diplayteamstatus("魔王陣営", monsterList);
                            System.out.println();
                        }
                        break;
                    }
                    case 3 :{
                        // ここで攻撃をする際のモンスターの攻撃方法選択はcharacter_heroリストから持ち出し、
                        // 攻撃を受ける側の場合はheroListやmonsterListから選択
                        int monster_i = rand.nextInt(monsterList.size());
                        CharacterCreate turn_battlemonster = charactercreates_monster.get(monster_i);
                        BattleCharacter defencemonster = monsterList.get(monster_i);
                        System.out.println(turn_battlemonster.get_name()+ "が現れました！  現在のHp:"+ turn_battlemonster.get_currenthp());
                        charactercreates_hero.add(turn_battlemonster);
                        
                        // 戦闘陣営対決
                        // character_heroの中に少なくともチームごとの所属キャラクターが少なくとも一体存在
                        while (defencemonster.get_currenthp() > 0){

                            // まずはcharactercreatesをキャラクターの速さで降順にソート
                            Collections.sort(charactercreates_hero, new Comparator<CharacterCreate>() {
                                @Override
                                public int compare(CharacterCreate c1, CharacterCreate c2) {
                                    // speed の降順（大きいほうが先に来る）
                                    return Integer.compare(c2.get_speed(), c1.get_speed());
                                        }
                                    });
                            
                            System.out.println();
                            int turn = 1;
                            System.out.println("====ターン" + turn + "====");
                            for (CharacterCreate battlecr : charactercreates_hero){
                                
                                if (battlecr.get_team() == Team.hero){
                                    if (defencemonster.get_currenthp() == 0) break;
                                    System.out.println();
                                    System.out.println(battlecr.get_name() + "の攻撃ターンです。攻撃する魔王陣営は" + turn_battlemonster.get_name() + "です。");
                                    // ここから攻撃処理の追加
                                    //which文でケース１と２で分けて入力で攻撃か回復かを選択。
                                    System.out.print("0:攻撃  1:回復  2:特殊攻撃　　発動したいスキルを選択してください：");
                                    int skill = scanner.nextInt();
                                    switch (skill){
                                        case 0:
                                            defencemonster.take_attack((int) battlecr.get_power());
                                            if (defencemonster.get_currenthp() <= 0){
                                                monsterList.remove(defencemonster);
                                                charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                                charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                                System.out.println();
                                                break;
                                            }
                                            System.out.println();
                                            break;
                                        case 1:
                                            double amount = battlecr.get_recovery();
                                            int recoveryCharacter = 0;
                                            for (BattleCharacter character : heroList){
                                                System.out.println("キャラクター名" + recoveryCharacter + "： "+ character.get_name() + "Hp" + character.get_currenthp());
                                                recoveryCharacter ++;
                                            }
                                            System.out.println("回復したいキャラクターを選択して下さい。");
                                            int hero_i = scanner.nextInt();
                                            heroList.get(hero_i).take_recovery((double) amount);
                                            System.out.println();
                                            break;
                                        case 2:
                                            battlecr.attack();
                                            defencemonster.take_attack((int) battlecr.get_currentpower());
                                            if (defencemonster.get_currenthp() <= 0){
                                                monsterList.remove(defencemonster);
                                                charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                                charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                                System.out.println();
                                                break;
                                            }
                                            System.out.println();
                                            break;
                                        default :
                                            System.out.println("無効な入力です。");
                                            System.out.println();
                                            break;
                                    }
                                }
                                // 魔王陣営の攻撃ターン
                                
                                else if (battlecr.get_team() == Team.monster_devil || battlecr.get_team() == Team.monster_goblin){
                                    if (defencemonster.get_currenthp() == 0) break;
                                    int hero_index = rand.nextInt(heroList.size());
                                    BattleCharacter defencehero = heroList.get(hero_index);
                                    CharacterCreate turn_battlhero = charactercreates_hero.get(hero_index);
                                    System.out.println();
                                    System.out.println(battlecr.get_name()+ "のターン\n" + defencehero.get_name()+ "が攻撃対象に選ばれました！  現在のHp:"+ defencehero.get_currenthp());
                                    // 攻撃処理
                                    defencehero.take_attack((int) battlecr.get_power());
                                    if (defencehero.get_hp() <= 0){
                                        heroList.remove(defencehero);
                                        charactercreates_hero.removeIf(character -> character.equals(turn_battlhero));
                                    }
                                    // 攻撃処理を増やしてモンスターの特殊攻撃をしたいなら
                                    //ここにcharactercreates_monsterから選択しattack
                                }
                                if (defencemonster.get_currenthp() <= 0){
                                    monsterList.remove(defencemonster);
                                    charactercreates_hero.removeIf(character -> character.equals(turn_battlemonster));
                                    charactercreates_monster.removeIf(character -> character.equals(turn_battlemonster));
                                    System.out.println();
                                    break;
                                }
                                turn++;
                            }
                        
                            //ターン終了時の状態表示
                            System.out.println();
                            diplayteamstatus("勇者陣営", heroList);
                            diplayteamstatus("魔王陣営", monsterList);
                            System.out.println();
                        }
                        break;
                    }
                    default :
                        System.out.println("無効な入力値です。");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("無効な入力です。数値を入力してください。");
                scanner.next();
            }   
        }
        // どちらかのリストが空になったときの勝利宣言
        if (heroList.isEmpty()){
            System.out.println("魔王陣営の勝利！！！");
        } else {
            System.out.println("勇者陣営の勝利！！！");
        }

        scanner.close();
    }

    // 各キャラクターのステータス情報表示
    public static void diplayteamstatus(String teamname, List<BattleCharacter> team){
        //陣営にキャラクターがいる場合だけ表示させるようにする
        if (!team.isEmpty()){
            System.out.println("====="+ teamname + "=====");
            for (BattleCharacter character : team){
                if (character.get_team() == Team.hero){
                    System.out.println("キャラクター名： "+ character.get_name() + " HP: "+ character.get_currenthp() + " 攻撃力: " + character.get_power() + " 回復力: " + character.get_recovery() + "速さ: "+ character.get_speed() + " " + character.get_name() + "は" + teamname + "です。");

                }
                else if (character.get_team() == Team.monster_devil || character.get_team() == Team.monster_goblin){
                    System.out.println("キャラクター名： "+ character.get_name() + " HP: "+ character.get_currenthp() + " 攻撃力: " + character.get_power() + " 回復力: " + character.get_recovery() + "速さ: "+ character.get_speed() + " " + character.get_name() + "は魔王陣営です。");
                }
                
            }
        }
    }
}
