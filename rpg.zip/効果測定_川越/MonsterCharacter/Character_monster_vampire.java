package 効果測定_川越.MonsterCharacter;

import 効果測定_川越.Abstract_character.Character;
import 効果測定_川越.CharacterCreation.*;
import 効果測定_川越.Team.*;

//吸血鬼
public class Character_monster_vampire extends Character {
    private CharacterCreate cmv;

    public Character_monster_vampire() {
        cmv = new CharacterCreate.Builder(Team.monster_devil, "上級ヴァンパイア", 10000, 1200, 5)
                            .recovery(2000)
                            .defence(1000)
                            .majical(1000)
                            .build();
    }

    @Override
    public void attack(){
        int power = cmv.get_power() + 1000;
        cmv.set_currentpower(power);
        System.out.println("上級ヴァンパイアは翼で攻撃をした！");
        
    }

    // 与え通常回復力を自分の現在のhpに＋するという特殊機能を追加したい
    public void recovery_attack(){
        int power = 500;
        cmv.set_currentpower(power);
        double hp =  cmv.get_currenthp() + cmv.get_recovery();
        cmv.set_currenthp(hp);
        System.out.println("上級ヴァンパイアはHPを" + cmv.get_currenthp() + "まで回復させました。");
    }
}
