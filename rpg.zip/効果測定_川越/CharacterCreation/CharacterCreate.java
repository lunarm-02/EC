package 効果測定_川越.CharacterCreation;

import 効果測定_川越.Team.*;

//キャラクター作成
public class CharacterCreate  {

    private int hp;
    private double currenthp;
    private int power;
    private int currentpower;
    private String name;
    private int speed;
    private Team team;
    private Integer recovery;
    private Integer defence;
    private Integer majical;

        // // ゴブリンの基本設計
        // public CharacterCreate (Team team, String name, int hp, int power, int speed){
        //     this.team = team;
        //     this.name = name;
        //     this.hp = hp;
        //     this.currenthp = hp;
        //     this.power = power;
        //     this.currentpower = power;
        //     this.speed = speed;
        // }

    // 勇者陣営・魔王陣営の基本設計
    protected CharacterCreate (Builder Builder){
        this.team = Builder.team;
        this.name = Builder.name;
        this.hp = Builder.hp;
        this.currenthp = Builder.hp;
        this.power = Builder.power;
        this.currentpower = Builder.power;
        this.speed = Builder.speed;
        this.recovery = Builder.recovery;
        this.defence = Builder.defence;
        this.majical = Builder.majical;
    }

    public static class Builder {
        // final　を付けて必須パラメータにした
        private final Team team;
        private final String name;
        private final int hp;
        private final int power;
        private final int speed;

        // 任意パラメータなので（デフォルト値を設定）
        private Integer recovery = null;
        private Integer defence = null;
        private Integer majical = null;

        public Builder (Team team, String name, int hp, int power, int speed){
            this.team = team;
            this.name = name;
            this.hp = hp;
            this.power = power;
            this.speed = speed;
        }

        public Builder recovery(int recovery){
            this.recovery = recovery;
            return this;
        }

        public Builder defence(int defence){
            this.defence = defence;
            return this;
        }

        public Builder majical(int majical){
            this.majical = majical;
            return this;
        }

        public CharacterCreate build(){
            return new CharacterCreate(this);
        }

    }

    // equals() と hashCode() のオーバーライドを追加する
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        CharacterCreate other = (CharacterCreate) obj;
        // ここではキャラクターの名前が同じなら同一とみなす例
        return this.name != null && this.name.equals(other.name);
    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : 0;
    }

    // 情報を取得
    public int get_hp(){
        return this.hp;
    }
    public double get_currenthp(){
        return this.currenthp;
    }
    public int get_power(){
        return this.power;
    }
    public int get_currentpower(){
        return this.currentpower;
    }
    public String get_name(){
        return this.name;
    }
    public Team get_team(){
        return this.team;
    }
    public int get_speed(){
        return this.speed;
    }
    public int get_recovery(){
        return this.recovery;
    }
    public int get_defence(){
        return this.defence;
    }
    public int get_majical(){
        return this.majical;
    }

    // 設定
    public void set_hp(int hp){
        this.hp = hp;
    }
    public void set_currenthp(double currenthp){
        if (currenthp <= 0){
            this.currenthp = 0;
            System.out.println(get_name() + "キャラクターは倒されました。");
        }
        else if (currenthp >= this.hp){
            this.currenthp = this.hp;
        }
        else{
            this.currenthp = currenthp;
            System.out.println(get_name() + "のHPは残り" + get_currenthp() + "です。");
        }
    }
    public void set_power(int power){
        this.power = power;
    }
    public void set_currentpower(int power_0){
        this.currentpower = power_0;
    }
    public void set_name(String name){
        this.name = name;
    }
    public void set_team(Team team){
        this.team = team;
    }
    public void set_speed(int speed){
        this.speed = speed;
    }
    public void set_recovery(int recovery){
        this.recovery = recovery;
    }
    public void set_defence(int defence){
        this.defence = defence;
    }
    public void set_majical(int majical){
        this.majical = majical;
    }
}


