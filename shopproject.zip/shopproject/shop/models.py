from django.db import models

# Create your models here.

from accounts.models import CustomUser

class Category(models.Model):
    '''投稿する写真を管理するモデル
    '''
    # カテゴリ名のフィールド
    title = models.CharField(
        verbose_name="カテゴリ", # フィールドのタイトル
        max_length=20)
    
    def __str__(self):
        '''オブジェクトを文字列に変換して返す

        Returns(str):カテゴリ名
        '''
        return self.title
    
class ShopPost(models.Model):

    '''投稿されたデータを管理するモデル
    '''
    # CustomUserモデル(のuser_id)とPhotoPostモデルを
    # 一対多の関係で結びつける
    # CustomUserが親でPhotoPostが子の関係となる
    user = models.ForeignKey(
        CustomUser,
        # フィールドのタイトル
        verbose_name='ユーザー',
        # ユーザを削除する場合はそのユーザの投稿データもすべて削除する
        on_delete=models.CASCADE
        )

    # Categoryモデル（のtitle）とPhotoPostモデルを
    # １対多の関係で結びつける
    # Categoryが親でPhotoPostが子の関係となる
    category = models.ForeignKey(
        Category,
        # フィールドのタイトル
        verbose_name='カテゴリ',
        # カテゴリに関連付けられた投稿データが存在する場合は
        # そのカテゴリを削除できないようにする
        on_delete = models.PROTECT
        )
    
    
    
    # タイトル用のフィールド
    title = models.CharField(
        verbose_name='タイトル', # フィールドのタイトル
        max_length=200        # 最大文字数は200
        )
    # コメント用のフィールド
    comment = models.TextField(
        verbose_name='コメント',  # フィールドのタイトル
        )
    # イメージのフィールド1
    image1 = models.ImageField(
        verbose_name='イメージ1',# フィールドのタイトル
        upload_to = 'photos'   # MEDIA_ROOT以下のphotosにファイルを保存  
        )
    # イメージのフィールド2
    image2 = models.ImageField(
        verbose_name='イメージ2',# フィールドのタイトル
        upload_to = 'photos',  # MEDIA_ROOT以下のphotosにファイルを保存
        blank=True,            # フィールド値の設定は必須でない
        null=True              # データベースにnullが保存されることを許容
        )
    
    # 投稿日時のフィールド
    posted_at = models.DateTimeField(
        verbose_name='投稿日時', # フィールドのタイトル
        auto_now_add=True       # 日時を自動追加
        )
    
    def __str__(self):
        '''オブジェクトを文字列に変換して返す
        
        Returns(str):投稿記事のタイトル
        '''
        return self.title
    


class CommentPost(models.Model):
    # 投稿されたデータごとを第二のindex.htmlのようにする
    shop_post = models.ForeignKey(ShopPost,
    on_delete=models.CASCADE,
    verbose_name='投稿'
    )

    text=models.TextField(verbose_name='コメント')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='作成日時')

    rating = models.PositiveSmallIntegerField(
        verbose_name='評価',
        choices=[(i, i) for i in range(1, 6)],  # 1から5までの選択肢
        default=3  # デフォルト値を3に設定
        )

    def __str__(self):
        return self.text[:20]

class PricePost(models.Model):
    shop_post = models.ForeignKey(ShopPost,
    on_delete=models.CASCADE,
    verbose_name='投稿'
    )
    # 金額のフィールド
    price = models.DecimalField(verbose_name='金額', max_digits=10, decimal_places=0, default = 0)
    # 数量のフィールド
    quantity = models.PositiveIntegerField(verbose_name='数量', default=1)

class CartPost(models.Model):
    user = models.ForeignKey(CustomUser, verbose_name='ユーザー', on_delete=models.CASCADE)  # ユーザー外部キー
    shop_post = models.ForeignKey(ShopPost, on_delete=models.CASCADE, verbose_name='投稿' )
    quantity2 = models.PositiveIntegerField(verbose_name='数量', default=0)