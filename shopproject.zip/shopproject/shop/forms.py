from django import forms
from .models import ShopPost, CommentPost, PricePost, CartPost
'''ModelFormのサブクラス
'''

class ShopPostForm(forms.ModelForm):
    '''ModelFormのサブクラス

    '''
    price = forms.DecimalField( max_digits=10, decimal_places=2, required=False, initial=1000.00)
    # 数量のフィールド
    quantity = forms.IntegerField( required=False, initial=1.00)
    
    # text=forms.CharField( widget=forms.Textarea)
    # rating = forms.ChoiceField(
        
    #     choices=[(i, i) for i in range(1, 6)],  # 1から5までの選択肢
    #     initial=3  # デフォルト値を3に設定
    #     )

    class Meta:
        '''ModelFormのインナークラス
        
        Attrubutes:
            model:モデルのクラス
            firelds:フォームで使用するモデルのフィールドを指定
        '''
        model=ShopPost
        fields = ['category', 'title', 'comment', 'image1', 'image2']

    def save(self, commit=True):
        # ShopPostを保存
        shop_post = super().save(commit=False)
        if commit:
            shop_post.save()
        # PricePostを保存
        price_post = PricePost(shop_post=shop_post, price=self.cleaned_data['price'], quantity=self.cleaned_data['quantity'])
        if commit:
            price_post.save()
        
        # # CommentPostを保存
        # comment_post = CommentPost(shop_post=shop_post, text=self.cleaned_data['text'], rating=self.cleaned_data['rating'])
        # if commit:
        #     comment_post.save()

        return shop_post
    
    
    

    
class CommentPostForm(forms.ModelForm):

    # text=forms.CharField( widget=forms.Textarea)
    # rating = forms.ChoiceField(choices=[(i, i) for i in range(1, 6)], initial=3)


    class Meta:
        model=CommentPost
        fields = [ 'text', 'rating']

    # shop_postをフィールドとして追加
    shop_post = forms.ModelChoiceField(queryset=ShopPost.objects.all(), widget=forms.HiddenInput)
    def save(self, commit=True):
        
        # # # CommentPostを保存
        # comment_post = CommentPost( shop_post=self.cleaned_data['shop_post'], text=self.cleaned_data['text'], rating=self.cleaned_data['rating'])
        # if commit:
        #     comment_post.save()
        # CommentPostを保存
        comment_post = super().save(commit=False)
        # shop_postを設定
        comment_post.shop_post = self.cleaned_data['shop_post']
        if commit:
            comment_post.save()
        return comment_post

class PricePostForm(forms.ModelForm):
    class Meta:
        model=PricePost
        fields = [ 'shop_post', 'price', 'quantity', ]

class CartPostForm(forms.ModelForm):

    class Meta:
        model=CartPost
        fields = ['quantity2']
    shop_post = forms.ModelChoiceField(queryset=ShopPost.objects.all(), widget=forms.HiddenInput)
    def save(self, commit=True):
        # ShopPostを保存
        cart_post = super().save(commit=False)
        cart_post.user = self.instance.user
        
        if commit:
            cart_post.save()
        # PricePostを保存
        
        # # CommentPostを保存
        # comment_post = CommentPost(shop_post=shop_post, text=self.cleaned_data['text'], rating=self.cleaned_data['rating'])
        # if commit:
        #     comment_post.save()

        return cart_post
