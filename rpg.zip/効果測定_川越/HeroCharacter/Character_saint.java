package 効果測定_川越.HeroCharacter;

import 効果測定_川越.Abstract_character.Character;
import 効果測定_川越.CharacterCreation.*;
import 効果測定_川越.Team.*;

// 聖女の作成
public class Character_saint extends Character {
    private CharacterCreate charactersaint;

    public Character_saint(){
        charactersaint = new CharacterCreate.Builder(Team.hero, "聖女", 5000, 500, 2)
                            .recovery(1000)
                            .defence(500)
                            .majical(1000)
                            .build();
    }

    public void attack(){
        int power = charactersaint.get_power() + 1000;
        charactersaint.set_currentpower(power);
        System.out.println("聖女は神聖力で攻撃した！");
    }
}
