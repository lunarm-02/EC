package 効果測定_川越.MonsterCharacter;

import 効果測定_川越.Abstract_character.Character;
import 効果測定_川越.CharacterCreation.*;
import 効果測定_川越.Team.*;

//ゴブリンオーガ作成
public class Character_monster_goblinogre extends Character {
    private CharacterCreate cmgg;

    public Character_monster_goblinogre(){
        cmgg = new CharacterCreate.Builder(Team.monster_goblin, "ゴブリンオーガ", 200, 50, 3)
                    // 任意パラメータなし
                    .build();
    }

    @Override
    public void attack() {
        int power_0 = cmgg.get_power() + 1000;
        cmgg.set_currentpower(power_0);
        System.out.println("ゴブリンオーガは斧で攻撃した！");
    }
}
