package 効果測定_川越.HeroCharacter;

import 効果測定_川越.Abstract_character.Character;
import 効果測定_川越.CharacterCreation.*;
import 効果測定_川越.Team.*;


// 勇者の作成
public class Character_hero extends Character {
    private CharacterCreate characterhero;

    public Character_hero(){
        // コンストラクタを呼び出す際に任意パラメータと必須パラメータを分けた形で生成することができるようになった
        characterhero = new CharacterCreate.Builder(Team.hero, "勇者", 5000, 2000, 5)
                            // 任意パラメータ（オプションの設定）
                            .recovery(1000)
                            .defence(500)
                            .majical(1000)
                            // ここでCharacterCreateコンストラクタを
                            // Builderで指定した属性でオブジェクトを作成
                            .build();
    }

    @Override
    public void attack() {
        int power_0 = characterhero.get_power() + 1000;
        characterhero.set_currentpower(power_0);
        System.out.println("勇者は聖剣で攻撃した！");
    }
}


