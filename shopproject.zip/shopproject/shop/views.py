from django.shortcuts import render, redirect
# Create your views here.

from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
# django.views.genericからTemplateView, ListViewをインポート
from django.views.generic import TemplateView, ListView

# django.views.genericからCreateViewをインポート
from django.views.generic import CreateView
# django.urlsからreverse_lazyをインポート
from django.urls import reverse_lazy
# formsモジュールからPhotoPostFormをインポート
from .forms import ShopPostForm, PricePostForm, CommentPostForm, CartPostForm
# django.views.genericからDetailViewをインポート
from django.views.generic import DetailView
# method_decoratorをインポート
from django.utils.decorators import method_decorator
# login_requiredをインポート
from django.contrib.auth.decorators import login_required
# modelsモジュールからモデルPhotoPostをインポート
from .models import ShopPost, PricePost, CommentPost, CartPost
# django.views.genericからDetailViewをインポート
from django.views.generic import DeleteView
# django.views.generic import DeleteView

# カートに商品を追加するための関数
def add_to_cart(request, shop_post_id):
    shop_post = get_object_or_404(ShopPost, id=shop_post_id)

    # フォームを初期化
    form = CartPostForm(request.POST or None)
    
    # ユーザーが認証されている場合
    
    # フォームが送信された場合
    if form.is_valid():
        # フォームデータを使用してCartPostインスタンスを保存
        cart_post = form.save(commit=False)
        cart_post.user = request.user  # ユーザー情報を保存
        cart_post.shop_post = shop_post  # 対象の商品を保存
        # カートに保存
        cart_item, created = CartPost.objects.get_or_create(user=request.user, shop_post=shop_post)
        if not created:
            cart_item.quantity2 += 1
            cart_post.save()
            cart_item.save()
            # 商品詳細ページにリダイレクト
        # 商品詳細ページにリダイレクトするだけのもいいけど
        # indexに戻るときのリダイレクトも記述したい。
        return redirect('shop:detail', pk=shop_post.id)

    # 認証されていない場合などの処理
    
    # # 商品を取得
    # shop_post = get_object_or_404(ShopPost, id=shop_post_id)
    # # カートにアイテムを追加、または数量を増やす
    cart_item, created = CartPost.objects.get_or_create(user=request.user, shop_post=shop_post)
    if not created:
        cart_item.quantity2 += 1
        cart_item.save()

    # 同じページ（商品詳細ページ）に戻る
    # return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
    return redirect('shop:detail', pk=shop_post.id)


class IndexView(ListView):
    '''トップページのビュー
    '''
    # index.htmlをレンダリングする
    template_name = 'index.html'
    # モデルBlogPostのオブジェクトにorder_by()を利用して
    # 投稿日時の降順で並べ替える
    # 1ページに表示するレコードの件数
    paginate_by = 8
    # ここでテーブルに存在しているすべてのカテゴリを選択できるように
    # カテゴリフィールドのidをテンプレートで取得できるようにしたい
    def get_queryset(self):
        return ShopPost.objects.all().order_by('-posted_at')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        shop_posts = ShopPost.objects.all().order_by('-posted_at')
        price_posts = PricePost.objects.all().order_by('price')
        combined_date = []

        for shop_post in shop_posts:
            price_post = price_posts.filter(shop_post=shop_post).first()
            # ここで二つのテーブルから使用するフィールドを抽出
            
            if price_post:
                combined_date.append({
                    'id': shop_post.id,
                    'user':shop_post.user,
                    'user_id':shop_post.user.id,
                    'category_id':shop_post.category.id,
                    'category_title':shop_post.category.title,
                    'title': shop_post.title,
                    'image1': shop_post.image1,
                    'image2': shop_post.image2,
                    'price': price_post.price
                })
        
        # デバッグ出力
        # print(combined_date)

        context['combined_date'] = combined_date

        # カートへ挿入フォームをcontextに追加
        if self.request.user.is_authenticated:
            cart_items = CartPost.objects.filter(user=self.request.user)
            total_quantity = sum(item.quantity2 for item in cart_items)
            context['total_cart_quantity'] = total_quantity

        if self.request.user.is_authenticated:
            context['cartpostform'] = CartPostForm()



        return context
    
# デコレーターにより、CreatePhotoViewへのアクセスはログインユーザーに限定される
# ログイン状態でなければsettings.pyのLOGIN_URLにリダイレクトされる
@method_decorator(login_required, name='dispatch')
class CreateShopView(CreateView):
    '''写真投稿ページのビュー
    
    PhotoPostFormで定義されているモデルとフィールドと連携して
    投稿データをデータベースに登録する
    
    Attributes:
        form_class: モデルとフィールドが登録されたフォームクラス
        template_name: レンダリングするテンプレート
        success_url: データベスへの登録完了後のリダイレクト先
    '''
    # forms.pyのPhotoPostFormをフォームクラスとして登録
    form_class = ShopPostForm
    # レンダリングするテンプレート
    template_name = "Shop_display.html"
    # フォームデータ登録完了後のリダイレクト先
    success_url = reverse_lazy('shop:shop_display_success')

    def form_valid(self, form):
        '''フォームが有効な場合にデータを保存する'''
        # PhotoPostFormを保存して、commit=Falseでデータを一時保存
        postdata = form.save(commit=False)
        postdata.user = self.request.user  # ユーザー情報を関連付け
        postdata.save()

        # PricePostFormの保存
        price_post_form = PricePostForm(self.request.POST)
        if price_post_form.is_valid():
            price_post = price_post_form.save(commit=False)
            price_post.shop_post = postdata  # PhotoPostと関連付け
            price_post.save()

        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        '''テンプレートにフォームを渡すためのコンテキストデータを準備'''
        context = super().get_context_data(**kwargs)
        # PhotoPostFormのインスタンスを追加
        context['shop_post_form'] = ShopPostForm()
        # PricePostFormのインスタンスも渡す
        context['price_post_form'] = PricePostForm()
        # カートへ挿入フォームをcontextに追加
        if self.request.user.is_authenticated:
            cart_items = CartPost.objects.filter(user=self.request.user)
            total_quantity = sum(item.quantity2 for item in cart_items)
            context['total_cart_quantity'] = total_quantity
        return context

    # def form_valid(self, form):
    #     '''CreateViewクラスのform_valid()をオーバーライド
        
    #     フォームのバリデーションを通過したときに呼ばれる
    #     フォームデータの登録をここで行う
        
    #     parameters:
    #         form(django.forms.Form):
    #         form_classに格納されているPhotoPostFormオブジェクト
    #     Return:
    #         HttpResponseRedirectオブジェクト:
    #         スーパークラスのform_valid()の戻り値を返すことで、
    #         success_urlで設定されているURLにリダイレクトさせる
    #     '''
    #     # commit=FalseにしてPOSTされたデータを取得
    #     postdata = form.save(commit=False)
    #     # 投稿ユーザーのidを取得してモデルのuserフィールドに格納
    #     postdata.user = self.request.user
    #     # 投稿データをデータベースに登録
    #     postdata.save()
    #     # 戻り値はスーパークラスのform_valid()の戻り値(HttpResponseRedirect)
    #     return super().form_valid(form)
    
class Shop_display_SuccessView(TemplateView):
    '''投稿ページのビュー
    
    Attributes:
        template_name:レンダリングするテンプレート
    '''
    # index.htmlをレンダリングする
    template_name = 'shop_display_success.html'
    def get_context_data(self, **kwargs):
        '''テンプレートにフォームを渡すためのコンテキストデータを準備'''
        context = super().get_context_data(**kwargs)

        # カートへ挿入フォームをcontextに追加
        if self.request.user.is_authenticated:
            cart_items = CartPost.objects.filter(user=self.request.user)
            total_quantity = sum(item.quantity2 for item in cart_items)
            context['total_cart_quantity'] = total_quantity

        return context

class By_categoryView(ListView):
    '''カテゴリページのビュー
    
    Attributes:
        template_name: レンダリングするテンプレート
        paginate_by: 1ページに表示するレコードの件数
    '''
    # index.htmlをレンダリングする
    template_name ='by_category.html'
    # 1ページに表示するレコードの件数
    paginate_by = 8
    # これって渡されたidに対してカテゴリに関連sるフィールドを返すだけで
    # カテゴリテーブルに入ってるidすべてを取り出してるわけじゃないから
    # カテゴリidをすべてしゅとくするためには、indexviewに書いているものをマネする
    def get_queryset(self):
        '''クエリを実行する

        self.kwargsの取得が必要なため、クラス変数querysetではなく、
        get_queryset（）のオーバーライドによりクエリを実行する

        Returns:
        クエリによって取得されたレコード
        '''     
        # self.kwargsでキーワードの辞書を取得し、
        # categoryキーの値(Categorysテーブルのid)を取得
        category_id = self.kwargs['category']
        # filter(フィールド名=id)で絞り込む
        categories = ShopPost.objects.filter(category=category_id).order_by('-posted_at')
        # クエリによって取得されたレコードを返す
        return categories

    def get_context_data(self, **kwargs):
        

        

        context = super().get_context_data(**kwargs)
        category_id = self.kwargs['category']
        # 絞り込みで商品を選択！！！！
        shop_posts = ShopPost.objects.filter(category=category_id).order_by('-posted_at')
        price_posts = PricePost.objects.all().order_by('price')
        user_date = []

        for shop_post in shop_posts:
            price_post = price_posts.filter(shop_post=shop_post).first()
            # ここで二つのテーブルから使用するフィールドを抽出
            
            if price_post:
                user_date.append({
                    'id': shop_post.id,
                    'category_id':shop_post.category.id,
                    'category_title':shop_post.category.title,
                    'user_id':shop_post.user.id,
                    'user':shop_post.user,
                    'title': shop_post.title,
                    'image1': shop_post.image1,
                    'image2': shop_post.image2,
                    'price': price_post.price
                })
        # デバッグ出力
        # print(user_date)
        context['user_date'] = user_date

        # カートへ挿入フォームをcontextに追加
        if self.request.user.is_authenticated:
            cart_items = CartPost.objects.filter(user=self.request.user)
            total_quantity = sum(item.quantity2 for item in cart_items)
            context['total_cart_quantity'] = total_quantity

        return context
    
class UserView(ListView):
    '''ユーザーの投稿一覧ページのビュー
    
    Attributes:
        template_name: レンダリングするテンプレート
        paginate_by: 1ページに表示するレコードの件数
    '''
    # index.htmlをレンダリングする
    template_name ='usercategory.html'
    # 1ページに表示するレコードの件数
    paginate_by = 8

    def get_queryset(self):
        '''クエリを実行する

        self.kwargsの取得が必要なため、クラス変数querysetではなく、
        get_queryset（）のオーバーライドによりクエリを実行する

        Returns:
        クエリによって取得されたレコード
        '''
        # self.kwargsでキーワードの辞書を取得し、
        # userキーの値(ユーザーテーブルのid)を取得
        user_id = self.kwargs['user']
        # filter(フィールド名=id)で絞り込む
        user_list = ShopPost.objects.filter(user=user_id).order_by('-posted_at')
        # クエリによって取得されたレコードを返す
        return user_list
    
    def get_context_data(self, **kwargs):
        

        

        context = super().get_context_data(**kwargs)
        user_id = self.kwargs['user']
        # 絞り込みで商品を選択！！！！
        shop_posts = ShopPost.objects.filter(user=user_id).order_by('-posted_at')
        price_posts = PricePost.objects.all().order_by('price')
        user_date = []

        for shop_post in shop_posts:
            price_post = price_posts.filter(shop_post=shop_post).first()
            # ここで二つのテーブルから使用するフィールドを抽出
            
            if price_post:
                user_date.append({
                    'id': shop_post.id,
                    'category_id':shop_post.category.id,
                    'category_title':shop_post.category.title,
                    'user':shop_post.user,
                    'title': shop_post.title,
                    'image1': shop_post.image1,
                    'image2': shop_post.image2,
                    'price': price_post.price
                })
        # デバッグ出力
        print(user_date)
        context['user_date'] = user_date

        # カートへ挿入フォームをcontextに追加
        if self.request.user.is_authenticated:
            cart_items = CartPost.objects.filter(user=self.request.user)
            total_quantity = sum(item.quantity2 for item in cart_items)
            context['total_cart_quantity'] = total_quantity

        return context

class ShopPostDetailView(DetailView):
    model = ShopPost
    template_name = 'detail.html'
    context_object_name = 'shop_post'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # 現在の商品に関連するコメントを取得
        comments = CommentPost.objects.filter(shop_post=self.object).order_by('-created_at')
        
        # コメント一覧をcontextに追加
        context['comments'] = comments
        
        # カートへ挿入フォームをcontextに追加
        if self.request.user.is_authenticated:
            cart_items = CartPost.objects.filter(user=self.request.user)
            total_quantity = sum(item.quantity2 for item in cart_items)
            context['total_cart_quantity'] = total_quantity
        # 商品に関連する価格情報を取得（PricePostと関連付け）
        price_post = PricePost.objects.filter(shop_post=self.object).first()
        
        # 価格情報をcontextに追加
        context['price_post'] = price_post
        
        return context
    
    

    
    # def post(self, request, *args, **kwargs):
    #     """POSTリクエストでカートに商品を追加"""
    #     shop_post = self.get_object()  # 現在表示している商品
    #     form = CartPostForm(request.POST)
        
    #     if form.is_valid():
    #         # フォームが有効ならカートに商品を追加
    #         quantity = form.cleaned_data['quantity2']  # 数量
            
    #         # ユーザーと商品、数量を基にカートアイテムを作成
    #         CartPost.objects.create(
    #             user=request.user,  # 現在のユーザー
    #             shop_post=shop_post,  # 商品
    #             quantity2=quantity,  # 数量
    #         )
            
    #         # 商品がカートに追加された後、カート詳細ページにリダイレクト
    #         return redirect('cart:cart_detail')  # カート詳細ページにリダイレクト

    #     # フォームが無効の場合は、商品詳細ページに戻す
    #     return self.get(request, *args, **kwargs)
    
@method_decorator(login_required, name='dispatch')
class Comment_display_View(CreateView):
    '''コメント投稿ページのビュー
    
    PhotoPostFormで定義されているモデルとフィールドと連携して
    投稿データをデータベースに登録する
    
    Attributes:
        form_class: モデルとフィールドが登録されたフォームクラス
        template_name: レンダリングするテンプレート
        success_url: データベスへの登録完了後のリダイレクト先
    '''
    # forms.pyのPhotoPostFormをフォームクラスとして登録
    form_class = CommentPostForm
    # レンダリングするテンプレート
    template_name = "comment_display.html"
    # フォームデータ登録完了後のリダイレクト先
    # 投稿したはずなのにリダイレクトされないんだけど？
    # フォームもちゃんと表示できてるし管理者画面で追加もできる
    # 投稿画面から投稿したときに保存されていない？だったらformsがおかしい？
    # それともviewか？
    # とりあえずエラーすら出ないからわからない。
    success_url = reverse_lazy('shop:comment_display_success')

    def form_valid(self, form):
        if not form.is_valid():
            print(form.errors) 
        '''CreateViewクラスのform_valid()をオーバーライド
        
        フォームのバリデーションを通過したときに呼ばれる
        フォームデータの登録をここで行う
        
        parameters:
            form(django.forms.Form):
            form_classに格納されているPhotoPostFormオブジェクト
        Return:
            HttpResponseRedirectオブジェクト:
            スーパークラスのform_valid()の戻り値を返すことで、
            success_urlで設定されているURLにリダイレクトさせる
        '''
        # commit=FalseにしてPOSTされたデータを取得
        postdata = form.save(commit=False)
        print(postdata)
        # 投稿ユーザーのidを取得してモデルのuserフィールドに格納
        postdata.user = self.request.user
        # 投稿データをデータベースに登録
        print(postdata.user)
        postdata.save()
        # 戻り値はスーパークラスのform_valid()の戻り値(HttpResponseRedirect)
        
        
        return super().form_valid(form)
# これは出てきているけど。。。中身のデータがわからない
# [23/Nov/2024 19:41:08] "GET /static/js/scripts.js HTTP/1.1" 404 1798
# {'form': <CommentPostForm bound=True, valid=False, fields=(shop_post;text;rating)>, 'view': <shop.views.Comment_display_View object at 0x000001A8B4E60160>, 'comment_post_form': <CommentPostForm bound=False, valid=Unknown, fields=(shop_post;text;rating)>, 'shop_post_form': <ShopPostForm bound=False, valid=Unknown, fields=(category;title;comment;image1;image2;price;quantity)>}
# [23/Nov/2024 19:41:17] "POST /comment_display/ HTTP/1.1" 200 5582
# [23/Nov/2024 19:41:17] "GET /static/js/scripts.js HTTP/1.1" 404 1798
    def get_context_data(self, **kwargs):
        '''テンプレートにフォームを渡すためのコンテキストデータを準備'''
        context = super().get_context_data(**kwargs)
        # PhotoPostFormのインスタンスを追加
        # 商品情報を取得
        shop_post = self.get_shop_post()
        if shop_post:
            context['comment_post_form'] = CommentPostForm(initial={'shop_post': shop_post})
        else:
            # shop_postが見つからない場合、エラーメッセージを表示
            context['error_message'] = "指定された商品が見つかりません。"

        
        # PricePostFormのインスタンスも渡す
        context['shop_post_form'] = ShopPostForm()
        print(context)

        # カートへ挿入フォームをcontextに追加
        if self.request.user.is_authenticated:
            cart_items = CartPost.objects.filter(user=self.request.user)
            total_quantity = sum(item.quantity2 for item in cart_items)
            context['total_cart_quantity'] = total_quantity

        return context
    
    def get_shop_post(self):
        # 商品IDをURLのパラメータか何かで取得してShopPostを取得する
        shop_post_id = self.kwargs.get('shop_post_id')
        return ShopPost.objects.get(id=shop_post_id)
    
class Comment_display_SuccessView(TemplateView):
    '''投稿ページのビュー
    
    Attributes:
        template_name:レンダリングするテンプレート
    '''
    # index.htmlをレンダリングする
    template_name = 'comment_display_success.html'
    def get_context_data(self, **kwargs):
        '''テンプレートにフォームを渡すためのコンテキストデータを準備'''
        context = super().get_context_data(**kwargs)

        # カートへ挿入フォームをcontextに追加
        if self.request.user.is_authenticated:
            cart_items = CartPost.objects.filter(user=self.request.user)
            total_quantity = sum(item.quantity2 for item in cart_items)
            context['total_cart_quantity'] = total_quantity

        return context

# カート詳細ページ
class CartDetailPostView(ListView):

    template__name = 'cartdetail.html'

    queryset = CartPost.objects.order_by('-posted_at')

    paginate_by = 10