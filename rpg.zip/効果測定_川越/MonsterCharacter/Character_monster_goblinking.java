package 効果測定_川越.MonsterCharacter;

import 効果測定_川越.Abstract_character.Character;
import 効果測定_川越.CharacterCreation.*;
import 効果測定_川越.Team.*;

// ゴブリンキング特有の攻撃スキル
public class Character_monster_goblinking extends Character {
    private CharacterCreate cmgk;
    // ゴブリンキング特有のスキルとキャラを作成
    public Character_monster_goblinking(){
        cmgk = new CharacterCreate.Builder(Team.monster_goblin, "ゴブリンキング", 300, 60, 2)
                    // 任意パラメータなし
                    .build();
    }

    @Override
    public void attack(){
        int power = cmgk.get_power() + 2000;
        cmgk.set_currentpower(power);
        System.out.println("ゴブリンキングは大斧で攻撃した！");
    }
}


