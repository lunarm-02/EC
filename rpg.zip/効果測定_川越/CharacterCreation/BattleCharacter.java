package 効果測定_川越.CharacterCreation;

//キャラクター情報の戦闘中の再設定
public class BattleCharacter extends CharacterCreate {
    

    //　戦闘中のキャラクター
    public BattleCharacter(CharacterCreate.Builder builder){
        super(builder);
    }

    //攻撃を受ける機能
    void take_attack(int amount){
        if (amount > 0){
            double currenthp = get_currenthp() - amount;
            System.out.println(get_name() + "は" + amount +"のダメージを受けた！");
            set_currenthp(currenthp);
        }
        
    }

    //回復を受ける機能
    void take_recovery(double amount){
        if (get_hp() < get_currenthp() + amount ){
            System.out.println("これ以上は回復できません。");
            double currenthp = get_hp();
            set_currenthp(currenthp);

        }
        else{
            double currenthp = get_currenthp() + amount;
            set_currenthp(currenthp);
            if (get_currenthp() > get_hp()){
                currenthp = get_hp();
                set_currenthp(currenthp);
            }
            System.out.println(get_name() + "はHPを" + get_currenthp() + "まで回復させました。");
        }
    }
}
