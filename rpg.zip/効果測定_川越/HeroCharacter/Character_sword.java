package 効果測定_川越.HeroCharacter;

import 効果測定_川越.Abstract_character.Character;
import 効果測定_川越.CharacterCreation.*;
import 効果測定_川越.Team.*;

// 剣士の作成
public class Character_sword extends Character {
    private CharacterCreate charactersword;

    public Character_sword(){
        charactersword = new CharacterCreate.Builder(Team.hero, "剣士", 5000, 3000, 3)
                            .recovery(1000)
                            .defence(500)
                            .majical(1000)
                            .build();
    }

    public void attack(){
        int power = charactersword.get_power() + 1000;
        charactersword.set_currentpower(power);
        System.out.println("剣士は名剣で攻撃した！");
    }
}