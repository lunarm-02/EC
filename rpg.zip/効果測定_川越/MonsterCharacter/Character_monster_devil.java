package 効果測定_川越.MonsterCharacter;

import 効果測定_川越.Abstract_character.Character;
import 効果測定_川越.CharacterCreation.*;
import 効果測定_川越.Team.*;

// 魔王の作成
public class Character_monster_devil extends Character {
    private CharacterCreate charactermonsterdevil0;

    public Character_monster_devil() {
        charactermonsterdevil0 = new CharacterCreate.Builder(Team.monster_devil, "魔王", 20000, 2000, 5)
                            .recovery(10000)
                            .defence(2000)
                            .majical(2000)
                            .build();
    }

    @Override
    public void attack(){
        int power = charactermonsterdevil0.get_power() + 1000;
        charactermonsterdevil0.set_currentpower(power);
        System.out.println("魔王は最後の魔剣で攻撃した！");
    }

    public void majical_attack(){
        int power = charactermonsterdevil0.get_power() + charactermonsterdevil0.get_majical();
        charactermonsterdevil0.set_currentpower(power);
        System.out.println("魔王は魔力のこもった攻撃を放った！");
    }
}

